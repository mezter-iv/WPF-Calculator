﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TheLastCalcuator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ClickNumber(object sender, RoutedEventArgs e) {
            Button button = sender as Button;

            if (button == erase)
            {
                if (label.Content != "") label.Content = label.Content.ToString().Remove(label.Content.ToString().Length - 1);
            }
            else if (button == ce) label.Content = "";
            else if (button == c)
            {
                label.Content = "";
                mainlabel.Content = "";
            }
            else if (button == dot)
            {
                if (!label.Content.ToString().Contains(".") && label.Content != "")
                {
                    label.Content += ".";
                }
            }
            else if (button == plusminus)
            {
                if (Convert.ToInt64(label.Content.ToString()) > 0)
                {
                    if (label.Content != "")
                    {
                        label.Content = "-" + label.Content;
                    }
                }
                else label.Content = Convert.ToInt64(label.Content.ToString()) * -1;
            }
            else if (button == plus || button == minnus || button == mult || button == div)
            {
                if (label.Content != "")
                {
                    label.Content += button.Content.ToString();
                    mainlabel.Content += label.Content.ToString();
                    label.Content = "";
                }
            }
            else if (button == equal) {
                if (mainlabel.Content.ToString() != "")
                {
                    mainlabel.Content += label.Content.ToString();
                    double number = Evaluate(mainlabel.Content.ToString());
                    mainlabel.Content = "";
                    label.Content = number.ToString();
                }
            }
            else
            {
                label.Content += (sender as Button).Content.ToString();
            }
        }
        private double Evaluate(string number) {
            try
            {
                var dt = new System.Data.DataTable();
                return Convert.ToDouble(dt.Compute(number, ""));
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
                return 0.0;
            }
        }
    }
}